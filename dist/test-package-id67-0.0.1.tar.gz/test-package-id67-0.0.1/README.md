## test package

Followed tutorial from here:
https://www.geeksforgeeks.org/how-to-build-a-python-package/
