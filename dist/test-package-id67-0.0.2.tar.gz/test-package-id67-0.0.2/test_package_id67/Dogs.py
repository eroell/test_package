class Dog:
    def __init__(self, name):
        self.name = name
        
    def makeNoise(self):
        return 'wuff'
